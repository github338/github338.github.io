DROP TABLE IF EXISTS `phpcms_globa`;
CREATE TABLE `phpcms_globa` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(10) NOT NULL DEFAULT 'text',
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `listorder` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

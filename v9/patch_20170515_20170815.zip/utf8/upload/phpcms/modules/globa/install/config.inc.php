<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'globa';
$modulename = '全局变量';
$introduce = '全局变量模块';
$author = 'villse';
$authorsite = '';
$authoremail = '';
?>
<?php
// self
$LANG['globa'] = '全局变量列表';
$LANG['globa_add'] = '添加全局变量';
$LANG['globa_name'] = '名称';
$LANG['globa_name_notice'] = '只允许是字母';
$LANG['globa_type'] = '类型';
$LANG['globa_content'] = '内容';
$LANG['edit'] = '修改';
$LANG['delete'] = '删除';
$LANG['my_globa_name_exist'] = '变量名称存在';
$LANG['add_success'] = '变量添加成功';
$LANG['edit_success'] = '变量修改成功';
$LANG['delete_success'] = '变量删除成功';
$LANG['errer_param'] = '参数错误';
$LANG['data_not_exist'] = '参数错误';



?>
<?php
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');

$parentid = $menu_db->insert(array('name'=>'globa','parentid'=>'29','m'=>'globa','c'=>'index','a'=>'init','data'=>'',"listorder"=>0,'display'=>'1'),true);
$menu_db->insert(array('name'=>'globa_add','parentid'=>$parentid,'m'=>'globa','c'=>'index','a'=>'add','data'=>'',"listorder"=>0,'display'=>'1'),true);
$menu_db->insert(array('name'=>'globa_edit','parentid'=>$parentid,'m'=>'globa','c'=>'index','a'=>'edit','data'=>'',"listorder"=>0,'display'=>'0'),true);

$language = array('globa'=>'全局变量','globa_add'=>'变量添加','globa_edit'=>'变量修改');
?>
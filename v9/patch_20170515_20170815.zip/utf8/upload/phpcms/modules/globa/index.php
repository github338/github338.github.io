<?php
defined('IN_PHPCMS') or exit('No permission resources.');
pc_base::load_app_class('admin','admin',0);
pc_base::load_sys_class('form','',0);
class index extends admin {
    public function __construct() {
		parent::__construct();
		$this->db = pc_base::load_model('globa_model');
		$this->type = array('text'=>'text','js'=>'js');
	}
    function init () {
        $data = $this->db->select('','*','','listorder DESC,id DESC');
        // echo "<pre>";
        // var_dump($data);exit;
        foreach ($data as $v) {
            $str_manage = '<a href="?m=globa&c=index&a=edit&id='.$v['id'].'&menuid='.$_GET['menuid'].'">'.L('edit').'</a> | <a href="javascript:confirmurl(\'?m=globa&c=index&a=delete&id='.$v['id'].'&menuid='.$_GET['menuid'].'\',\''.L('confirm',array('message'=>$v['name'])).'\')">'.L('delete').'</a> ';
			$v['content'] = strip_tags($v['content']);
            $str  .= "<tr>
                    <td align='center'><input name='listorders[{$v['id']}]' type='text' size='3' value='{$v['listorder']}' class='input-text-c'></td>
                    <td align='center'>{$v['id']}</td>
                    <td width='100' align='center'>{$v['name']}</td>
                    <td width='100' align='center'>{$v['type']}</td>
                    <td align='center'>{$v['content']}</td>
                    <td align='center'>$str_manage</td>
                </tr>";
            }
        include $this->admin_tpl('globa_index');
    }
    // 添加变量
    function add(){
		$types = $this->type;
        if(isset($_POST['dosubmit'])){
            $info = $_POST['info'];
            $r = $this->db->get_one(array('name'=>$info['name']));
            if(!$r){
                $this->db->insert($_POST['info']);
                setGloba();
                showmessage(L('add_success'),'?m=globa&c=index&a=init');
            }else{
                showmessage(L('my_globa_name_exist'),'?m=globa&c=index&a=init');
            }
        }
        include $this->admin_tpl('globa_index');
    }
    // 修改变量
    function edit(){
        if(isset($_POST['dosubmit'])){
            $id = intval($_POST['id']);
            $this->db->update($_POST['info'],array('id'=>$id));
            setGloba();
            showmessage(L('edit_success'),'?m=globa&c=index&a=init');
        }else{
            if(isset($_GET['id']) && !empty($_GET['id'])){
                $id = intval($_GET['id']);
                $r = $this->db->get_one(array('id'=>$id));
                // extract($r);
                extract($r);
                include $this->admin_tpl('globa_index');
            }else{
                showmessage(L('errer_param'),'?m=globa&c=index&a=init');
            }
        }
    }

    // 删除变量
    function delete(){
        $id = intval($_GET['id']);
        $r = $this->db->get_one(array('id'=>$id));
        if($r){
            $this->db->delete(array('id'=>$_GET['id']));
            setGloba();
            showmessage(L('delete_success'),'?m=globa&c=index&a=init');
        }else{
            showmessage(L('data_not_exist'),'?m=globa&c=index&a=init');
        }

    }
	//更新排序
 	public function listorder() {
		if(isset($_POST['dosubmit'])) {
			foreach($_POST['listorders'] as $linkid => $listorder) {
				$linkid = intval($linkid);
				$this->db->update(array('listorder'=>$listorder),array('id'=>$linkid));
			}
			showmessage(L('operation_success'),HTTP_REFERER);
		} 
	}

}


INSERT INTO `phpcms_menu` VALUES ('1669', 'my_globa', '29', 'globa', 'index', 'init', '', '0', '1', '1', '1', '1', '1', '1');
INSERT INTO `phpcms_menu` VALUES ('1670', 'my_globa_add', '1669', 'globa', 'index', 'add', '', '0', '1', '1', '1', '1', '1', '1');
INSERT INTO `phpcms_menu` VALUES ('1671', 'my_globa_edit', '1669', 'globa', 'index', 'edit', '', '0', '0', '1', '1', '1', '1', '1');

INSERT INTO `phpcms_module` VALUES ('globa', '自定义全局变量', '', '0', '', '', '', '0', '0', '2018-06-04', '2018-06-04');
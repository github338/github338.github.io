<?php
defined('IN_PHPCMS') or exit('Access Denied');
defined('UNINSTALL') or exit('Access Denied'); 
// $globa_db = pc_base::load_model('globa_model');
// $typeid = $globa_db->delete(array('module'=>'globa'));
return array('globa');
?>
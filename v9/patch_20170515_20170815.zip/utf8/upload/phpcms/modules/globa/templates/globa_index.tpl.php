<?php
defined('IN_ADMIN') or exit('No permission resources.');
include $this->admin_tpl('header', 'admin');?>

<?php if(ROUTE_A=='init') {?>
<form name="myform" action="?m=globa&c=index&a=listorder" method="post">
<div class="pad-lr-10">
<div class="table-list">
    <table width="100%" cellspacing="0">
        <thead>
            <tr>
            <th width="80"><?php echo L('listorder');?></th>
            <th width="100">id</th>
            <th width="100"><?php echo L('globa_name');?></th>
            <th><?php echo L('globa_type');?></th>
            <th><?php echo L('globa_content');?></th>
			<th><?php echo L('operations_manage');?></th>
            </tr>
        </thead>
	<tbody>
    
   <?php echo $str; ?>

	</tbody>
    </table>
  
    <div class="btn"><input type="submit" class="button" name="dosubmit" value="<?php echo L('listorder')?>" /> <span>全局变量模板调用代码{getGloba('name')}<input type="text" value="{getGloba('zhuanyuan')}" class="input-text" size="30"/></span></div>  </div>
</div>
</div>
</form>
</body>
</html>


<?php } elseif(ROUTE_A=='add') {?>
<script type="text/javascript">
<!--

//-->
</script>
<form name="myform" id="myform" action="?m=globa&c=index&a=add" method="post">

<div class="common-form">
<table width="100%" class="table_form contentWrap">

      <tr>
        <th> <?php echo L('globa_name')?>：</th>
        <td><input type="text" name="info[name]" id="name" class="input-text" >(<?php echo L('globa_name_notice')?>)</td>
      </tr>
	  <tr>
        <th> <?php echo L('globa_type')?>：</th>
        <td>
        	<?php
            	echo form::select($types,0,'name="info[type]"');
			?>
        </td>
      </tr>
      <tr>
        <th><?php echo L('globa_content')?>：</th>
        <td><textarea  name="info[content]" cols="100" rows="8" id="content"></textarea></td>
      </tr>

</table>
<!--table_form_off-->
</div>
    <div class="bk15"></div>
	<div class="btn"><input type="submit" id="dosubmit" class="button" name="dosubmit" value="<?php echo L('submit')?>"/></div>
</div>

</form>

<?php } elseif(ROUTE_A=='edit') {?>
<script type="text/javascript">
<!--

//-->
</script>
<form name="myform" id="myform" action="?m=globa&c=index&a=edit" method="post">

<div class="common-form">
<table width="100%" class="table_form contentWrap">
           <tr>
        <th> <?php echo L('globa_name')?>：</th>
        <td><input type="text" name="info[name]" id="name" value="<?php echo $name ; ?>" class="input-text" ></td>
      </tr>

      <tr>
        <th><?php echo L('globa_content')?>：</th>
        <td><textarea  name="info[content]" cols="100" rows="8" id="content"><?php echo $content ; ?></textarea></td>
      </tr>
</table>
<!--table_form_off-->
</div>
    <div class="bk15"></div>
	<input name="id" type="hidden" value="<?php echo $id?>">
    <div class="btn"><input type="submit" id="dosubmit" class="button" name="dosubmit" value="<?php echo L('submit')?>"/></div>
</div>

</form>
<?php }?>
</body>
</html>
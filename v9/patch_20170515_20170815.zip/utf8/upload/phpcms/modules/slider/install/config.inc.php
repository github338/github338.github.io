﻿<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'slider';
$modulename = '幻灯片模块';
$introduce = '幻灯片模块';
$author = 'bruce';
$authorsite = 'http://www.258en.com';
$authoremail = '214875213@qq.com';
?>
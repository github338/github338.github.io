<?php
$LANG['slider'] 							='幻灯片管理';
$LANG['slider_add'] 						=	'添加幻灯片';
$LANG['slider_name'] 						= 	'名称';
$LANG['image'] 							= 	'图片';
$LANG['url'] 							= 	'链接网址';
$LANG['typeid'] 						= 	'所属位置';
$LANG['status'] 						= 	'是否显示';
$LANG['isshow'] 						= 	'显示';
$LANG['notshow'] 						= 	'不显示';
$LANG['type_id'] 						= 	'位置ID';
$LANG['slider_listorder'] 	            =   '幻灯片排序';
$LANG['type_name'] 						= 	'分类名称';
$LANG['list_type'] 						= 	'分类管理';
$LANG['slider_type_listorder'] 			=	'排序权值';
$LANG['slider_adddate'] 			=	'添加日期';
$LANG['slider_desc'] 			=	'幻灯描述';
$LANG['slider_lable'] 			=	'标签调用';
$LANG['slider_click_view'] 			=	'点击查看';
$LANG['slider_postion_name']			= 	'位置名称';



$LANG['remove_all_selected']			=	'删除选中';

$LANG['slider_postion_noempty']				=	'幻灯片位置不能为空';
$LANG['add_success']					=	'提交成功,正在返回!';
$LANG['suspend_application']			=	'暂停申请,正在返回!';

$LANG['slider_exit']						=	'幻灯片不存在';
$LANG['slidertype_exit']					=	'幻灯片分类不存在';
$LANG['all_slidertype']					=	'所有分类';
$LANG['all']							=	'全部';


$LANG['before_select_operations']		=	'请选择再执行操作';

$LANG['yes']							=	'是';
$LANG['no']								=	'否';

$LANG['slider_list'] 						='幻灯片列表';
?>
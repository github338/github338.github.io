<?php
return array(
    'to_version' => 'V9.6.4',	//phpcms 版本号#两个模块
    'to_release' => '20170815',	//phpcms 更新日期
);
?>
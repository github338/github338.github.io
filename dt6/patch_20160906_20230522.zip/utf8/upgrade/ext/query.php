<?php
file_put_contents('1.txt','test');


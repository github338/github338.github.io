DROP TABLE IF EXISTS `destoon_config`;
CREATE TABLE IF NOT EXISTS `destoon_config` (
    `id` smallint(4) NOT NULL AUTO_INCREMENT,
    `action` varchar(255) NOT NULL,
    `hmbaidu` varchar(255) NOT NULL,
    `catids` int(1) NOT NULL,
    `toptitle` text NOT NULL,
    `copyright` text NOT NULL,
    `jmdt` text NOT NULL,
    `upgrade` varchar(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'action', '留言地址', '', 'varchar', 255, 'text', 'https://s.5918eat.com/api/message/post.html?key=077103d4792c58a35b61f30cc50516bc', '', 120, 90, '', 'size=\"80\"', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'hmbaidu', '百度js', '', 'varchar', 255, 'text', '', '', 120, 90, '', 'size=\"80\"', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'catids', '栏目多选', '', 'int', 1, 'radio', '0', '1|多选*\r\n0|单选*\r\n', 120, 90, '', '', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'toptitle', '顶部信息', '', 'text', 0, 'textarea', '', '', 120, 90, '', 'rows=\"5\" cols=\"80\"', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'copyright', '版权信息', '', 'text', 0, 'textarea', '', '', 120, 90, '', 'rows=\"5\" cols=\"80\"', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'jmdt', '加盟动态', '', 'text', 0, 'textarea', '', '', 120, 90, '', 'rows=\"5\" cols=\"80\"', 1, 1, 0);
INSERT INTO `destoon_fields` (`itemid`, `tb`, `name`, `title`, `note`, `type`, `length`, `html`, `default_value`, `option_value`, `width`, `height`, `input_limit`, `addition`, `display`, `front`, `listorder`) VALUES(0, 'config', 'upgrade', '升级目录', '', 'varchar', 50, 'text', 'dt6', '', 120, 90, '', 'size=\"30\"', 1, 1, 0);
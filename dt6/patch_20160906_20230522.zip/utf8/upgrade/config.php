<?php
return array(
    'to_version' => 'DT7.1.1',	// 版本号
    'to_release' => '20230522',	// 更新日期
);
?>
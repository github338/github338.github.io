<?php
return array(
    'to_version' => 'DT6.1.1',	// 版本号
    'to_release' => '20230828',	// 更新日期
);
?>
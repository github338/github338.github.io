<?php
return array(
    'to_version' => 'DT6.0.1',	// 版本号
    'to_release' => '20230629',	// 更新日期
);
?>